#include<stdio.h>

int main(void){
	int vetA[5];
	int vetB[5];
	int *pVetA;
	int *pVetB;
	int i=0;
	
	pVetA = vetA;
	pVetB = vetB;

	for(i=0; i<5;i++){
		printf("informe um numero:\n");
		scanf("%d", &*(pVetA+i));
	}

	for(i=0; i<5;i++){
		*(pVetB+i) = *(pVetA+i);
	}
	
	printf("\n\n");
	
	for(i=0; i<5;i++){
		printf("%d ", *(pVetB+i));
	}	
}
