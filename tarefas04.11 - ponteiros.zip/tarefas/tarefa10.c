#include<stdio.h>
int main (void){
	int vetorA[8];
	int vetorB[8];
	int *pA;
	int *pB;
	int i=0, n=0, cont=0;
	
	pA = vetorA;
	pB = vetorB;
	
	printf("Vetor A!!!\n");
	for(i=0;i<8;i++)
	{
		printf("informe um numero: ");
		scanf("%d", &n);
		
		if(n%2 == 0 || n%3 == 0)
		{
			*(pA+i) = n;
		}
		else
		{
			i--;
		}
	}
	
	printf("\n Vetor B!!!\n");
	for(i=0;i<8;i++)
	{
		printf("informe um numero: ");
		scanf("%d", &n);
		
		if (n%5 == 0)
		{
			*(pB+i) = n;
		}
		else
		{
			i--;
		}
	}
	
	printf("Vetor A!!!\n");
	
	for(i=0;i<8;i++)
	{
		printf("%d ", *(pA+i));
	}
	printf("\n Vetor B!!!\n");
	for(i=0;i<8;i++)
	{
		printf("%d ", *(pB+i));
	}
	
	
}
