#include<stdio.h>

void somatorio(int *vetA){
	
	int vetorB[5];
	int *ptrvetB;
	
	int i=0, n=0, soma=0;
	
	ptrvetB = vetorB;
	
	for(i=0;i<5;i++)
	{
		n = *vetA+i;
		
		for(soma = 1; n > 1; n = n - 1)
		{
			soma = soma + n;
		}
		*(ptrvetB+i) = soma;
	}

	for(i=0; i<5;i++){
		printf("%d ", *(vetA+i));
	}
	
	printf("\n\n");
	
	for(i=0; i<5;i++){
		printf("%d ", *(ptrvetB+i));
	}

}

int main (void)
{
	int vetorA[5];
	int *ptrvetA;
	int i=0;
	
	ptrvetA = vetorA;
	
	for(i=0;i<5;i++){
		printf("informe um numero: ");
		scanf("%d", &*(ptrvetA+i));
	}
	
	somatorio(ptrvetA);
	
}
