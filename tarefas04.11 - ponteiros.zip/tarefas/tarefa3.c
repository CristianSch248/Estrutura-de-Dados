#include<stdio.h>
int main(void){
	int vetor[15];
	int i, maior=0;
	int *ptrvet;
	
	ptrvet = vetor;
	
	
	for(i=0;i<15;i++){
		printf("informe um valor: ");
		scanf("%d", &*(ptrvet+i));//ver como fiz na 1
	}
	
	for(i=0;i<15;i++){
		if(*ptrvet+i > 5)
		{
			maior++;
		}
	}
	
	printf("o total de numeros maiores que 5 eh: [%d]", maior);
	
}
