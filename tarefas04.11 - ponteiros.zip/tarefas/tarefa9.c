#include<stdio.h>

int main (void){
	
	int vetorA[6];
	int vetorB[6];
	int vetorC[6];
	int vetorD[6];
	
	int *pA;
	int *pB;
	int *pC;
	int *pD;
	
	int i=0, aux=0, aux2=0;
	
	pA = vetorA;
	pB = vetorB;
	pC = vetorC;
	pD = vetorD;
	
	printf("VETOR A!!!\n");
	
	for(i=0;i<6;i++)
	{
		printf("informe um valor: ");
		scanf("%d", &*(pA+i));
	}
	
	printf("VETOR B!!!\n");
	
	for(i=0;i<6;i++)
	{
		printf("informe um valor: ");
		scanf("%d", &*(pB+i));
	}
	
	for(i=0;i<6;i++)
	{
		if(i%2 != 0){
			*(pC + aux) = *(pA + i);
			*(pC + (aux + 1)) = *(pB + i);
			aux = aux + 2;
		}
		else
		{
			*(pD+aux2) = *(pA+i);
			*(pD + (aux2 + 1)) = *(pB + i);
			aux2 = aux2 + 2;	
		}
	}
	
	printf("PAR!!!\n");
	
	for(i=0;i<6; i++)
	{
		printf("%d ", *(pD+i));
	}
	
	printf("\nIMPAR!!!\n");
	
	for(i=0;i<6; i++)
	{
		printf("%d ", *(pC+i));
	}
}
