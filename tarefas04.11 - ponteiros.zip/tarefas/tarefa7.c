#include<stdio.h>

void junta (int *vetA, int *vetB){
	
	int vetorC[14];
	int *ptrvetC;
	int i=0, a=0, b=0;
	ptrvetC = vetorC;
	
	for(i=0;i<14;i++)
	{
		if(i<5)
		{
			*(ptrvetC+a) = *(vetA+a);
			a++;
		}
		else
		{
			*(ptrvetC+i) = *(vetB+b);
			b++;
		}
	}
	
	for(i=0; i<13;i++)
	{
		printf("%d ", *(ptrvetC+i));
	}	
}

int main(void){
	
	int vetorA[5];
	int vetorB[8];

	int *ptrvetA;
	int *ptrvetB;

	int i=0;
	
	ptrvetA = vetorA;
	ptrvetB = vetorB;
	
	printf("vetor A\n");
	
	for(i=0;i<5;i++){
		printf("informe um numero:");
		scanf("%d", &*(ptrvetA+i));//vet como fiz na 1
	}
	
	printf("vetor B\n");
	
	for(i=0;i<8;i++){
		printf("informe um numero:");
		scanf("%d", &*(ptrvetB+i));//1
	}
	
	junta(ptrvetA, ptrvetB);
	
}
