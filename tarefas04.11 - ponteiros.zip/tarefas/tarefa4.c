//Crie um programa que leia 15 elementos de um vetor A.
// Construir um vetor B de mesmo tipo, observando a seguinte lei de forma��o: 
//Todo elemento de B deve ser o quadrado do elemento de A correspondente.
//Apresentar os 2 vetores
#include<stdio.h>

void quadrado(int *vetA){
	
	int i;
	int vetorB[15];
	int *ptrvetB;
	
	for(i=0;i<15;i++){
		*(ptrvetB+i)= *(vetA+i) * *(vetA+i);
	}
	
	
	for(i=0; i<15;i++){
		printf("%d ", *(vetA+i));
	}
	
	printf("\n\n");
	
	for(i=0; i<15;i++){
		printf("%d ", *(ptrvetB+i));
	}
}

int main(void){	
	int vetorA[15];
	int i;
	int *ptrvetA;
	ptrvetA = vetorA;
	
	for(i=0;i<15;i++){
		printf("informe um valor: ");
		scanf("%d", &*(ptrvetA+i));//vet como fiz na 1
	}	
	
	quadrado(ptrvetA);
	
}
