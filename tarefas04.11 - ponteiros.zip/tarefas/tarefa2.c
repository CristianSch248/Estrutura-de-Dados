#include<stdio.h>
int main(void){
	
	int n, i;
	int vetor[11];
	int *ptrvet;
	
	ptrvet = vetor;
	
	printf("informe um numero para efetura a tabuada: ");
	scanf("%d", &n);
	
	for(i=0;i<=10;i++){
		*ptrvet+i = n * i;
	}
	
	for(i=0; i<10;i++){
		printf("%d ", *(ptrvet+i));
	}
	
	
	
}
