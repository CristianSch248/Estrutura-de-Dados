#include<stdio.h>

void fatorial(int *vetA){

	int i, fatorial, n;
	long int vetorB[15];
	long int *ptrvetB;
	
	ptrvetB = vetorB;

	for(i=0;i<15;i++)
	{
		n = *vetA+i;
		
		for(fatorial = 1; n > 1; n = n - 1)
		{
			fatorial = fatorial * n;
		}
		*(ptrvetB+i) = fatorial;	
	}
	
	for(i=0; i<15;i++){
		printf("%d ", *(vetA+i));
	}
	
	printf("\n\n");
	
	for(i=0; i<15;i++){
		printf("%li ", *(ptrvetB+i));
	}
}

int main(void){
	int vetorA[15];
	int i;
	int *ptrvetA;
	
	ptrvetA = vetorA;
	
	for(i=0;i<15;i++)
	{
		printf("informe um numero:");
		scanf("%d", &*(ptrvetA+i));
	}
	
	fatorial(ptrvetA);
}
