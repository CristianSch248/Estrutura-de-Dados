#include<stdio.h>

void mostra(float *vet){
	
	int i;
	
	for(i=4;i>=0;i--)
	{
		printf("%.2f ", *(vet+i));
	}
	
}

int main(void)
{
	float vetor[5];	
	float *ptrvet;
	int i;
	
	ptrvet = vetor;
	
	for(i=0;i<5;i++)
	{
		printf("informe um numero real: ");
		scanf("%f", &*(ptrvet+i));//vet como fiz na 1
	}
	mostra(ptrvet);
		
}
